import styles from "./styles.module.css"
import axios from "axios"
import { useState, useEffect } from "react"
// var CanvasJSReact = require('../../canvasjs.react');
import CanvasJSReact from '../../canvasjs.react';
var CanvasJS = CanvasJSReact.CanvasJS;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;

const Main = () => {

    const [error, setError] = useState("")
    const [data, setData] = useState("")
    const [weatherCityValues, setWeatherCityValues] = useState([])
    const [weatherCity2Values, setWeatherCity2Values] = useState([])
    const [startDate, setStartDate] = useState("")
    const [endDate, setEndDate] = useState("")
    const [city, setCity] = useState("")
    const [city2, setCity2] = useState("")

    const handleLogout = () => {
        localStorage.removeItem("token")
        localStorage.removeItem("user_id")
        window.location.href = "/"
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        try {
            const format = "json";
            const api = "457THATVJ938EKY23SD29AZXW";

            const url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/history?&aggregateHours=24&" +
                "startDateTime=" + startDate.target.value + "T00:00:00&endDateTime=" + endDate.target.value + "T00:00:00&unitGroup=uk&contentType=" + format + "&" +
                "dayStartTime=0:0:00&dayEndTime=0:0:00&location=" + city.target.value + "&key=" + api;

            const url2 = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/history?&aggregateHours=24&" +
                "startDateTime=" + startDate.target.value + "T00:00:00&endDateTime=" + endDate.target.value + "T00:00:00&unitGroup=uk&contentType=" + format + "&" +
                "dayStartTime=0:0:00&dayEndTime=0:0:00&location=" + city2.target.value + "&key=" + api;


            axios.get(url).then((allWeather) => {
                // console.log(allWeather.data.locations[city.target.value].values)
                // console.log(allWeather)
                const values = allWeather.data.locations[city.target.value].values
                // const values = allWeather.data.locations

                setWeatherCityValues(weatherCityValues => ({
                    ...values
                }));
            })
            axios.get(url2).then((allWeather) => {
                // console.log(allWeather.data.locations[city2.target.value].values)
                const values = allWeather.data.locations[city2.target.value].values
                // const values = allWeather.data.locations

                setWeatherCity2Values(weatherCity2Values => ({
                    ...values
                }));
            })
        } catch (error) {
            if (error.response && error.response.status >= 400 && error.response.status <= 500) {
                setError(error.response.specifiedData.message)
            }
        }
    }

    function display() {

        if (weatherCityValues[0] != undefined) {
            // console.log(weatherCityValues[0].temp)
            var tempArrCity1 = []
            // weatherCityValues.map((value, key) => (
            //     tempArrCity1.push(value.temp)
            // ))
            console.log(weatherCityValues.length)

            for(var i = 0; i < weatherCityValues.length; i++){
                tempArrCity1[i] = weatherCityValues[i].temp
                // console.log(weatherCityValues[i].temp)
            }

            // console.log(tempArrCity1)

            const options = {
                animationEnabled: true,
                title: {
                    text: "Porównanie pogody między " + city.target.value + " i " + city2.target.value
                },
                axisY: {
                    title: "Temperatura"
                },
                toolTip: {
                    shared: true
                },
                data: [{
                    type: "spline",
                    name: "2016",
                    showInLegend: true,
                    dataPoints: [
                        { y: 155, label: "Jan" },
                        { y: 150, label: "Feb" },
                        { y: 152, label: "Mar" },
                        { y: 148, label: "Apr" },
                        { y: 142, label: "May" },
                        { y: 150, label: "Jun" },
                        { y: 146, label: "Jul" },
                        { y: 149, label: "Aug" },
                        { y: 153, label: "Sept" },
                        { y: 158, label: "Oct" },
                        { y: 154, label: "Nov" },
                        { y: 150, label: "Dec" }
                    ]
                },
                {
                    type: "spline",
                    name: "2017",
                    showInLegend: true,
                    dataPoints: [
                        { y: 172, label: "Jan" },
                        { y: 173, label: "Feb" },
                        { y: 175, label: "Mar" },
                        { y: 172, label: "Apr" },
                        { y: 162, label: "May" },
                        { y: 165, label: "Jun" },
                        { y: 172, label: "Jul" },
                        { y: 168, label: "Aug" },
                        { y: 175, label: "Sept" },
                        { y: 170, label: "Oct" },
                        { y: 165, label: "Nov" },
                        { y: 169, label: "Dec" }
                    ]
                }]
            }

            return (
                <div>
                    <CanvasJSChart options={options}
                    /* onRef={ref => this.chart = ref} */
                    />
                    {/*You can get reference to the chart instance as shown above using onRef. This allows you to access all chart properties and methods*/}
                </div>
            );
        }
    }

    useEffect(() => {
        // console.log(weatherCityValues)
        // console.log(weatherCity2Values)
    })

    return (
        <div className={styles.main_container}>
            <nav className={styles.navbar}>
                <h1>Strona główna</h1>
                <button className={styles.white_btn} onClick={handleLogout}>
                    Wyloguj się
                </button>
            </nav>
            <form className={styles.form_container} onSubmit={handleSubmit}>
                <input
                    type="date"
                    placeholder="Data rozpoczęcia"
                    name="startDate"
                    onChange={e => setStartDate(e)}
                    className={styles.input1}
                    required
                />
                <input
                    type="date"
                    placeholder="Data zakończenia"
                    name="endDate"
                    onChange={e => setEndDate(e)}
                    className={styles.input1}
                    required
                />
                <input
                    type="text"
                    placeholder="Miasto pierwsze"
                    name="city"
                    onChange={e => setCity(e)}
                    className={styles.input1}
                    required
                />
                <input
                    type="text"
                    placeholder="Miasto drugie"
                    name="city2"
                    onChange={e => setCity2(e)}
                    className={styles.input1}
                    required
                />
                <button type="submit">
                    Pogoda
                </button>
            </form>
            <div>
                {display()}
            </div>
            <div>

            </div>
        </div>
    )
}

export default Main