import styles from "./styles.module.css"
import { Link } from "react-router-dom"
const Main = () => {
    const handleLogout = () => {
        localStorage.removeItem("token")
        localStorage.removeItem("user_id")
        window.location.href = "/"
    }

    return (
        <div className={styles.main_container}>
            <nav className={styles.navbar}>
                <h1>Strona główna</h1>
                <button className={styles.white_btn} onClick={handleLogout}>
                    Wyloguj się
                </button>
            </nav>

            <div class={styles.center}>
                <Link to="/weather">
                    <button type="button"
                        className={styles.green_btn}>
                        Sprawdź pogodę
                    </button>
                </Link>
            </div>
        </div>
    )
}
export default Main