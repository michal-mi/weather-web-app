import styles from "./styles.module.css"
import axios from "axios"
import { useState, useEffect } from "react"

const Main = () => {

    const [error, setError] = useState("")
    const [data, setData] = useState("")
    const [specifiedData, setSpecifiedData] = useState("")
    const [startDate, setStartDate] = useState("")
    const [endDate, setEndDate] = useState("")
    const [city, setCity] = useState("")

    const handleLogout = () => {
        localStorage.removeItem("token")
        localStorage.removeItem("user_id")
        window.location.href = "/"
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        try {
            const format = "json";
            const api = "C56Z3NHTBARVJ68SU6SEETZTT";

            const url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/history?&aggregateHours=24&" +
                "startDateTime=" + startDate.target.value + "T00:00:00&endDateTime=" + endDate.target.value + "T00:00:00&unitGroup=uk&contentType=" + format + "&" +
                "dayStartTime=0:0:00&dayEndTime=0:0:00&location=" + city.target.value + "&key=" + api;
            axios.get(url).then((allWeather) => {
                console.log(allWeather)
                setSpecifiedData(allWeather.specifiedData)
            })
        } catch (error) {
            if(error.response && error.response.status >= 400 && error.response.status <= 500){
                setError(error.response.specifiedData.message)
            }
        } 
        // console.log(specifiedData)
    }

    return (
        <div className={styles.main_container}>
            <nav className={styles.navbar}>
                <h1>Strona główna</h1>
                <button className={styles.white_btn} onClick={handleLogout}>
                    Wyloguj się
                </button>
            </nav>
            <form className={styles.form_container} onSubmit={handleSubmit}>
                <input
                    type="date"
                    placeholder="Data rozpoczęcia"
                    name="startDate"
                    onChange={e => setStartDate(e)}
                    className={styles.input1}
                />
                <input
                    type="date"
                    placeholder="Data zakończenia"
                    name="endDate"
                    onChange={e => setEndDate(e)}
                    className={styles.input1}
                />
                <input
                    type="text"
                    placeholder="Miasto"
                    name="city"
                    onChange={e => setCity(e)}
                    className={styles.input1}
                />
                <button type="submit">
                    Pogoda
                </button>
            </form>
        </div>
    )
}

export default Main